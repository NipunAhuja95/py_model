// Master.js
import React from 'react';

const Master = () => {
  return (
    <div className="p-6">
      <h1 className="text-xl font-semibold"></h1>
      {/* Add actual Master component code here */}
    </div>
  );
};

export default Master;

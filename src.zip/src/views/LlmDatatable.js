import React, { useEffect, useRef } from "react";
import $ from "jquery";
import "datatables.net-dt/css/dataTables.dataTables.css";
import "datatables.net";

function LlmDatatable({ headers, data }) {
  const tableRef = useRef(null);
  const dataTableRef = useRef(null);

  useEffect(() => {
    if (!headers.length || !tableRef.current) return;

    const columns = headers.map((h) => ({
      title: h.title,
      data: h.data,
    }));

    // Destroy previous table if exists
    if (dataTableRef.current) {
      dataTableRef.current.clear().destroy();
      dataTableRef.current = null;
    }

    // Initialize new DataTable
    dataTableRef.current = $(tableRef.current).DataTable({
      data,
      columns,
      paging: true,
      searching: true,
      ordering: true,
      scrollX: true,
      pageLength: 10,
      destroy: true,
    });

  }, [headers, data]);

  return (
    <div>
      <table ref={tableRef} className="display w-full text-xs nowrap"></table>
    </div>
  );
}

export default LlmDatatable;

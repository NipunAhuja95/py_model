import React, { useState, useRef } from "react";
import loader from '../1484.gif';
import { useMutation } from "@tanstack/react-query";
import axios from "axios";
import { toast } from "react-hot-toast";
import { Button, Drawer, Select, MenuItem, Dialog, DialogTitle, List, ListItem, ListItemButton, ListItemText } from "@mui/material";
import LlmDatatable from "./LlmDatatable";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";

const COLORS = [
    "#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#0088FE", "#00C49F", "#FFBB28", "#FF8042"
];

const LLM = () => {
    const [headers, setHeaders] = useState([]);
    const [data, setData] = useState([]);
    const [inputPrompt, setInputPrompt] = useState("");
    const [isLoader, setIsLoader] = useState(false);
    const [llmTextResponse, setLlmTextResponse] = useState("");

    // Visualization states
    const [openChartDialog, setOpenChartDialog] = useState(false);
    const [selectedChart, setSelectedChart] = useState('');
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [chartConfigData, setChartConfigData] = useState([{ column: '' }, { column: '' }]);
    const [seriesData, setSeriesData] = useState([]);
    const [xAxis, setXAxis] = useState([]);
    const [yAxis, setYAxis] = useState([]);
    const containerRef = useRef(null);

    // Backend call
    const saveDataMutation = useMutation({
        mutationFn: (promptData) => axios.post("http://localhost:8083/llm/ask", promptData),
        onSuccess: (response) => {
            setIsLoader(false);
            const res = response.data;

            if (res.data && res.columns) {
                const columnsArray = Array.isArray(res.columns) ? res.columns : Array.from(res.columns);
                const formattedColumns = columnsArray.map(col => ({
                    title: col.replace(/_/g, " ").toUpperCase(),
                    data: col
                }));

                setData(res.data);
                setHeaders(formattedColumns);
                setLlmTextResponse("Executed SQL: " + res.sql);

                // Prepare chart defaults
                setSeriesData(columnsArray);
                setChartConfigData([{ column: columnsArray[0] }, { column: columnsArray[0] }]);
                setXAxis([]);
                setYAxis([]);
                toast.success(res.response || "Query executed successfully.");
                setInputPrompt("");
            } else if (res.error) {
                setLlmTextResponse("Error: " + res.error);
                toast.error(res.response || "Query failed.");
            } else {
                toast.error("No usable data returned.");
            }
        },
        onError: (error) => {
            setIsLoader(false);
            setData([]);
            setHeaders([]);
            toast.error("Could not execute query.");
            console.error(error);
        }
    });

    const executePrompt = async () => {
        if (!inputPrompt.trim()) return;
        setIsLoader(true);
        try {
            await saveDataMutation.mutateAsync({ prompt: inputPrompt });
        } catch (error) {
            console.error(error);
            setIsLoader(false);
        }
    };

    // Chart Dialog
    const handleOpenChartDialog = () => setOpenChartDialog(true);
    const handleCloseChartDialog = () => setOpenChartDialog(false);
    const handleChartSelect = (chart) => {
        setSelectedChart(chart);
        setIsDrawerOpen(true);
        handleCloseChartDialog();
    };

    const handleDropdownChange = (index, value) => {
        const chartConfig = [...chartConfigData];
        chartConfig[index].column = value;
        setChartConfigData(chartConfig);
    };

    const handleVisualize = () => {
        if (!data.length) return toast.error("No data to visualize.");
        const x = data.map(row => row[chartConfigData[0].column]);
        const y = data.map(row => row[chartConfigData[1].column]);
        setXAxis(x);
        setYAxis(y);
        setIsDrawerOpen(false);
    };

    const renderChart = () => {
        if (!xAxis.length || !yAxis.length) return null;

        switch (selectedChart) {
            case "line":
                return (
                    <ResponsiveContainer width="100%" height={400}>
                        <LineChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey={chartConfigData[0].column} />
                            <YAxis domain={['auto', 'auto']} />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey={chartConfigData[1].column} stroke={COLORS[0]} />
                        </LineChart>
                    </ResponsiveContainer>
                );
            case "bar":
                return (
                    <ResponsiveContainer width="100%" height={400}>
                        <BarChart data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey={chartConfigData[0].column} />
                            <YAxis domain={['auto', 'auto']} />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey={chartConfigData[1].column}>
                                {data.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                );
            case "pie":
                return (
                    <ResponsiveContainer width="100%" height={400}>
                        <PieChart>
                            <Pie
                                data={data}
                                dataKey={chartConfigData[1].column}
                                nameKey={chartConfigData[0].column}
                                cx="50%"
                                cy="50%"
                                outerRadius={150}
                                label
                            >
                                {data.map((entry, index) => (
                                    <Cell key={`slice-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                            <Legend />
                        </PieChart>
                    </ResponsiveContainer>
                );
            default:
                return null;
        }
    };

    return (
        <div id="mainContainer" ref={containerRef} className="h-screen w-full flex flex-col overflow-hidden p-3">
            <div className="flex-1 flex flex-col border rounded-lg bg-white p-4 shadow">
                {/* Visualize button */}
                <div className="flex justify-end mb-2">
                    {data.length > 0 && headers.length > 0 && (
                        <Button variant="contained" size="small" onClick={handleOpenChartDialog}>
                            Visualize
                        </Button>
                    )}
                </div>

                <div className="flex-1 overflow-auto">
                    {!isLoader && (
                        <>
                            {llmTextResponse && (
                                <div className="mb-4 p-3 bg-gray-100 text-sm rounded shadow border border-gray-300">
                                    <strong>{llmTextResponse}</strong>
                                </div>
                            )}
                            {data.length > 0 && headers.length > 0 && (
                                <LlmDatatable headers={headers} data={data} />
                            )}
                            {renderChart()}
                        </>
                    )}
                    {isLoader && (
                        <div className="flex w-full h-full justify-center items-center">
                            <img src={loader} alt="Loading..." />
                        </div>
                    )}
                </div>

                {/* Prompt Input */}
                <div className="w-full min-h-20 mt-2 flex flex-col border bg-gray-50 rounded-lg">
                    <textarea
                        className="w-full h-full resize-none p-2 outline-none text-sm"
                        placeholder="Ask me anything (e.g. 'show me 10 rows from table xyz')..."
                        value={inputPrompt}
                        onChange={(e) => setInputPrompt(e.target.value)}
                    />
                    <div className="flex justify-end p-1">
                        <Button onClick={executePrompt} variant="contained" size="small">
                            Execute
                        </Button>
                    </div>
                </div>
            </div>

            {/* Chart type dialog */}
            <Dialog open={openChartDialog} keepMounted onClose={() => setOpenChartDialog(false)}>
                <DialogTitle>Select Chart Type</DialogTitle>
                <List sx={{ pt: 0 }}>
                    {['line', 'bar', 'pie'].map(chart => (
                        <ListItem key={chart} disablePadding>
                            <ListItemButton onClick={() => handleChartSelect(chart)}>
                                <ListItemText primary={chart.charAt(0).toUpperCase() + chart.slice(1) + ' Chart'} />
                            </ListItemButton>
                        </ListItem>
                    ))}
                </List>
            </Dialog>

            {/* Drawer for X/Y selection */}
            <Drawer anchor="right" open={isDrawerOpen} variant="persistent" container={containerRef.current} PaperProps={{ style: { top: 0, right: 0, width: 300 } }}>
                <div className="p-4">
                    <h3 className="mb-2 font-semibold">Select Columns</h3>
                    <div className="mb-2">
                        <label className="text-xs">X Axis:</label>
                        <Select fullWidth value={chartConfigData[0].column} onChange={(e) => handleDropdownChange(0, e.target.value)}>
                            {seriesData.map((col, i) => <MenuItem key={i} value={col}>{col}</MenuItem>)}
                        </Select>
                    </div>
                    <div className="mb-2">
                        <label className="text-xs">Y Axis:</label>
                        <Select fullWidth value={chartConfigData[1].column} onChange={(e) => handleDropdownChange(1, e.target.value)}>
                            {seriesData.map((col, i) => <MenuItem key={i} value={col}>{col}</MenuItem>)}
                        </Select>
                    </div>
                    <Button variant="contained" fullWidth onClick={handleVisualize}>Submit</Button>
                </div>
            </Drawer>
        </div>
    );
};

export default LLM;

package com.ey.model.controller;

import java.util.*;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import com.ey.model.config.DatabaseTools;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/llm")
@CrossOrigin("*")
public class LLMController {

    private final ChatClient chatClient;
    private final JdbcTemplate jdbcTemplate;
    private final DatabaseTools databaseTools;

    public LLMController(OllamaChatModel chatModel, JdbcTemplate jdbcTemplate, DatabaseTools databaseTools) {
        this.chatClient = ChatClient.create(chatModel);
        this.jdbcTemplate = jdbcTemplate;
        this.databaseTools = databaseTools;
    }

    @PostMapping("/ask")
    public Map<String, Object> ask(@RequestBody Map<String, String> request) {
        String prompt = request.get("prompt");
        String sql = null;

        try {
            if (prompt.trim().toLowerCase().startsWith("select")) {
                sql = prompt;
            } else {
                String resp = chatClient.prompt()
                        .user("Convert this into a valid SQL query for my database: " + prompt)
                        .tools(databaseTools)
                        .call()
                        .content();

                sql = extractSQLFromResponse(resp);
            }

            if (sql == null || sql.isEmpty()) throw new RuntimeException("No valid SQL extracted from response.");

            // Block dangerous queries
            String lowerSql = sql.toLowerCase();
            if (lowerSql.contains("drop") || lowerSql.contains("delete") ||
                lowerSql.contains("update") || lowerSql.contains("insert")) {
                throw new RuntimeException("Dangerous SQL detected: " + sql);
            }

            // Add LIMIT if missing
            if (!lowerSql.contains("limit")) sql += " LIMIT 50";

            // Quote column names in SELECT if needed
            sql = quoteColumnsInSelect(sql);

            // Execute query
            List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

            // Normalize keys
            List<Map<String, Object>> normalizedRows = new ArrayList<>();
            Set<String> columns = new LinkedHashSet<>();
            for (Map<String, Object> row : rows) {
                Map<String, Object> newRow = new LinkedHashMap<>();
                for (Map.Entry<String, Object> entry : row.entrySet()) {
                    String safeKey = entry.getKey().replace(" ", "_").replace(".", "_");
                    newRow.put(safeKey, entry.getValue());
                    columns.add(safeKey);
                }
                normalizedRows.add(newRow);
            }

            return Map.of(
                    "data", normalizedRows,
                    "columns", columns,
                    "sql", sql,
                    "response", "Query executed successfully."
            );

        } catch (Exception e) {
            return Map.of(
                    "error", e.getMessage(),
                    "sql", sql != null ? sql : "N/A",
                    "response", "Could not execute query."
            );
        }
    }

    // --- Helper methods ---
    private String extractSQLFromResponse(String resp) {
        try {
            if (resp.contains("{\"sql\"")) {
                int start = resp.indexOf("{\"sql\"");
                int end = resp.indexOf("}", start);
                String jsonPart = resp.substring(start, end + 1);
                ObjectMapper mapper = new ObjectMapper();
                Map<String, String> jsonMap = mapper.readValue(jsonPart, new TypeReference<Map<String, String>>() {});
                return jsonMap.get("sql");
            } else if (resp.contains("```sql")) {
                int start = resp.indexOf("```sql") + 6;
                int end = resp.indexOf("```", start);
                if (end > start) return resp.substring(start, end).trim();
            } else {
                for (String line : resp.split("\n")) {
                    String trimmed = line.trim();
                    if (trimmed.toLowerCase().startsWith("select")) return trimmed;
                }
            }
        } catch (Exception e) {
            // fallback
        }
        return null;
    }

    private String quoteColumnsInSelect(String sql) {
        // Replace any column like S.no -> "S.no"
        String[] parts = sql.split("(?i)select|from");
        if (parts.length < 2) return sql;

        String selectPart = parts[1];
        String[] columns = selectPart.split(",");
        for (int i = 0; i < columns.length; i++) {
            String col = columns[i].trim();
            if (col.contains(".") || col.contains(" ")) {
                columns[i] = "\"" + col + "\"";
            }
        }
        sql = sql.replace(selectPart, String.join(", ", columns));
        return sql;
    }
}

package com.ey.model.config;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class DatabaseTools {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Tool(description = "Execute a SQL query against the database and return results")
    public List<Map<String, Object>> executeSql(String sql) {
    	 String lower = sql.toLowerCase();
         if (lower.contains("drop") || lower.contains("delete") || lower.contains("update")) {
             throw new IllegalArgumentException("Dangerous query blocked: " + sql);
         }
         return jdbcTemplate.queryForList(sql);
    }
}
